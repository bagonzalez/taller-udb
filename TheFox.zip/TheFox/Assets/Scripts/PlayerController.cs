﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour {

	public float alturaDeSalto;
	public float velocidad;
	private Rigidbody2D player;
	private bool isJumping;
	private Animator myAnimator;
	private bool izquierda;
	private bool derecha;

	void Awake(){
		player = GetComponent<Rigidbody2D> ();
		myAnimator = GetComponent<Animator> ();
	}


	void FixedUpdate () {
		if (player.velocity.y == 0) {
			isJumping = false;
		} else {
			isJumping = true;
		}

		if (Input.GetAxisRaw("Vertical") == 1 && !isJumping) {
			player.velocity = new Vector2 (2, 8);
	
		}

		if (Input.GetAxisRaw ("Horizontal") == -1) {
			player.velocity = new Vector2 (-3, 0);
			player.transform.localRotation = Quaternion.Euler(0, 180, 0);
			if (!isJumping) {
				myAnimator.SetBool("izquierda", true);
			}
		} 

		if (Input.GetAxisRaw("Horizontal") == 1) {
			player.velocity = new Vector2 (3, 0);
			player.transform.localRotation = Quaternion.Euler(0, 0, 0);
			if (!isJumping) {
				myAnimator.SetBool("izquierda", true);
			}
		}

		if (player.velocity.x == 0 ) {
			myAnimator.SetBool("izquierda", false);
		}
			

		myAnimator.SetFloat ("jumpUP", player.velocity.y+1);
		Debug.Log ("Velocidad X : " + player.velocity.x);
	}
}
